<template>
  <div id="app">
    <!-- <animation></animation>  动画旋转-->  
    <User></User>  
    <TimeDown endTimes="1554372000" :callback="TimeDownCallback" endText="已经结束了"></TimeDown>
    <This></This>
    

  </div>
</template>

<script>
import animation from '@/components/animation';       //360deg旋转
import TimeDown from '@/components/TimeDown';       //时间倒计时
import This from '@/components/This';
export default {
  name: 'App',
  components:{
    animation,TimeDown,This
  },
  methods:{
    TimeDownCallback(){     //倒计时结束回调
      console.log('倒计时已经结束');
      
    }
  },
  mounted:function(){
    console.log(this.req('https://wechat.gmxy.com.cn/api/List/GetGoodList'));
    
  }

  
}
</script>
 