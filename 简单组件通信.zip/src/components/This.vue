<style scoped>
</style>
<template>
  <div>{{name}}</div>
</template>



<script> 
export default {
  data() {
    return {
      name: "GGG"
    };
  },
  mounted: function() {  
       
      
  /*    var obj =   function() {
        console.log(this);
      } 
    obj ();   */
    /* ************************************************************************* */
    // var obj = {
    //   name: "Ghuayu",
    //   greet: function() {
    //     console.log(this.name);
    //   }
    // };
    // //obj.greet()                     //普通函数输出Ghuayu
    // obj.greet.call(this); //普通函数改变this指向
    // obj.greet.call({ name: "ABC" }); // this输出 ABC
    /* ************************************************************************* */
    /* const obj = {
      a: {
        b: {
          c: {
            d: function(){
              console.log(this);
              
            }
          }
        }
      }
    };

    obj.a.b.c.d(obj); */
  },
  methods: {}
};
</script>
