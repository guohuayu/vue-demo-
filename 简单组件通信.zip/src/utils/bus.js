//公共JS 引入VUE实例, 创建一个实例
import Vue from 'vue'
export default new Vue()